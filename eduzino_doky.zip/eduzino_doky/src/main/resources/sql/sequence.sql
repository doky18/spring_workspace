
create sequence seq_member
increment by 1
start with 1;

create sequence seq_sns_name
increment by 1
start with 1;

<<<<<<< HEAD
create sequence seq_birthday
increment by 1
start with 1;

create sequence seq_profile_photo
increment by 1
start with 1;

create sequence seq_email
increment by 1
start with 1;

=======
>>>>>>> 090364d14f2248e255f6a980387b9adb6e56c4f0
create sequence seq_teacher
increment by 1
start with 1;

create sequence seq_blacklist
increment by 1
start with 1;

create sequence seq_admin
increment by 1
start with 1;

create sequence seq_grade
increment by 1
start with 1;;

create sequence seq_top_category
increment by 1
start with 1;;

create sequence seq_mid_category
increment by 1
start with 1;

create sequence seq_section
increment by 1
start with 1;

create sequence seq_sub_category
increment by 1
start with 1;

create sequence seq_movie
increment by 1
start with 1;

create sequence seq_goal
increment by 1
start with 1;

create sequence seq_requirement
increment by 1
start with 1;

create sequence seq_subject
increment by 1
start with 1;

create sequence seq_cart
increment by 1
start with 1;

create sequence seq_wish
increment by 1
start with 1;

create sequence seq_order_summary
increment by 1
start with 1;

create sequence seq_payment
increment by 1
start with 1;

create sequence seq_paystate
increment by 1
start with 1;

create sequence seq_chat
increment by 1
start with 1;

create sequence seq_review
increment by 1
start with 1;

create sequence seq_adminboard
increment by 1
start with 1;

create sequence seq_target
increment by 1
start with 1;

create sequence seq_teacherboard
increment by 1
start with 1;

create sequence seq_message
increment by 1
start with 1;

create sequence seq_order_detail
increment by 1
start with 1;

create sequence seq_discount_log
increment by 1
start with 1;

create sequence seq_charge
increment by 1
start with 1;

create sequence seq_point_log
increment by 1
start with 1;

create sequence seq_point
increment by 1
start with 1;
