package com.edu.zino.domain;

import lombok.Data;

@Data
public class Charge {
	private int charge_idx;
	private int charge_ratio;//수수료 비율
}
