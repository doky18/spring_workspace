package com.edu.zino.domain;

import lombok.Data;

@Data
//할인내역
public class DiscountLog {

}
