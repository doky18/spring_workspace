package com.edu.zino.model.teacher;



import com.edu.zino.domain.Teacher;

public interface TeacherDAO {
	
	public Teacher select(int member_idx);

	
}
