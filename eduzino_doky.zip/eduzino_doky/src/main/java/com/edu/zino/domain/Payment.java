package com.edu.zino.domain;

import lombok.Data;

@Data
public class Payment {
	private int payment_idx;
	private String payment_type;//결제방식
	
}
