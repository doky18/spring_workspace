package com.edu.zino.domain;

import lombok.Data;

//공지 대상 DTO
@Data
public class Target {
	private int target_idx;
	private String userType;//공지대상
}
