package com.edu.zino.domain;

import lombok.Data;

@Data
public class Sns {
	private int sns_idx;
	private String sns_type; //1:구글	 2:카카오 3:네이버
}
