package com.edu.zino.domain;

import lombok.Data;

@Data
public class Paystate {
	private int paystate_idx;
	private String state;//결제 상태
}
