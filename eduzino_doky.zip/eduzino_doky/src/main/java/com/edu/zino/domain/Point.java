package com.edu.zino.domain;

import lombok.Data;

@Data
public class Point {
	private int point_idx;
	private int point_ratio;//적립율
}
