package com.edu.zino.model.root;

import java.util.List;

import com.edu.zino.domain.TopCategory;

public interface TopCategoryService {
	public List<TopCategory> selectAll();
}
