package com.edu.zino.controller.teacher;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestSubjectController {
	
	 
}
