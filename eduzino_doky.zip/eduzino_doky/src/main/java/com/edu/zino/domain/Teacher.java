package com.edu.zino.domain;

import lombok.Data;

@Data
public class Teacher extends Member{
	private int teacher_idx;//강사번호
}
